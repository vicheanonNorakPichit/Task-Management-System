import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;

public class AddTask { // CLASS FOR ADD TASK FRAME
    JPanel addPanel = new JPanel(); // PANEL FOR ADDING TASK
    JTextField taskNameField = new JTextField(); // INPUT TASK NAME
    JTextField descriptionField = new JTextField();
//    JDatePicker datePicker = new JDatePicker; USE DATE PICKER FROM GITHUB or STACKOVERFLOW
    Choice importance = new Choice(); // CHOOSE THE IMPORTANCE OF THE TASK
    JButton addBtn = new JButton("Add Task"); // ADD TASK BUTTON
}
