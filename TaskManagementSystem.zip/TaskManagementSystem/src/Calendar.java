import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Calendar { // CLASS FOR CALENDAR FRAME
    JFrame calendarFrame = new JFrame();
    JPanel calendarPanel = new JPanel();
    // CALENDAR HEADER //
    JPanel calendarHeader = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toCompletedButton = new JButton("Completed");
    // CALENDAR //
    JPanel mainPanel = new JPanel(); // Grid layout //
    Calendar() {
        calendarPanel.setLayout(new GridBagLayout());

        // HEADER //

        calendarHeader.setLayout(new FlowLayout());
        ((FlowLayout)calendarHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        c.ipadx = 1000;
        calendarPanel.add(calendarHeader, c);

            // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setPreferredSize(new Dimension(200,70));
        toDashboardButton.setPreferredSize(new Dimension(200, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setPreferredSize(new Dimension(200,70));
        toTaskListButton.setPreferredSize(new Dimension(200, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setPreferredSize(new Dimension(200,70));
        toCalendarButton.setPreferredSize(new Dimension(200, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel completedButton = new JPanel();
        completedButton.setPreferredSize(new Dimension(200,70));
        toCompletedButton.setPreferredSize(new Dimension(200, 50));
        toCompletedButton.setBackground(Color.white);
        completedButton.add(toCompletedButton);
        calendarHeader.add(dashboardButton);
        calendarHeader.add(taskListButton);
        calendarHeader.add(calendarButton);
        calendarHeader.add(completedButton);

        // Main Panel //
        mainPanel.setLayout(new GridLayout());
        mainPanel.setBackground(Color.green);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 700;
        c.ipadx = 1000;
        calendarPanel.add(mainPanel, c);

        calendarFrame.add(calendarPanel);
        calendarFrame.setResizable(false);
        calendarFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        calendarFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
