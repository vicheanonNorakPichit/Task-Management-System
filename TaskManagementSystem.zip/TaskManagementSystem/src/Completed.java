import javax.swing.*;
import java.awt.*;

public class Completed { // CLASS FOR COMPLETED FRAME
    JFrame completedFrame = new JFrame();
    JPanel completedPanel = new JPanel();
    JPanel completedHeader = new JPanel();
    JPanel completedMain = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toCompletedButton = new JButton("Completed");
    Completed() {
        completedPanel.setLayout(new GridBagLayout());

        // HEADER //

        completedHeader.setLayout(new FlowLayout());
        ((FlowLayout)completedHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        c.ipadx = 1000;
        completedPanel.add(completedHeader, c);

        // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setPreferredSize(new Dimension(200, 70));
        toDashboardButton.setPreferredSize(new Dimension(200, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setPreferredSize(new Dimension(200, 70));
        toTaskListButton.setPreferredSize(new Dimension(200, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setPreferredSize(new Dimension(200, 70));
        toCalendarButton.setPreferredSize(new Dimension(200, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel completedButton = new JPanel();
        completedButton.setPreferredSize(new Dimension(200, 70));
        toCompletedButton.setPreferredSize(new Dimension(200, 50));
        toCompletedButton.setBackground(Color.white);
        completedButton.add(toCompletedButton);
        completedHeader.add(dashboardButton);
        completedHeader.add(taskListButton);
        completedHeader.add(calendarButton);
        completedHeader.add(completedButton);

        // Main Panel //
        completedMain.setLayout(new GridLayout());
        completedMain.setBackground(Color.orange);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 700;
        c.ipadx = 1000;
        completedPanel.add(completedMain, c);

        completedFrame.add(completedPanel);
        completedFrame.setResizable(false);
        completedFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        completedFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
