import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard { //CLASS FOR DASHBOARD FRAME
    JFrame dashboardFrame = new JFrame();
    // HEADER DECLARATION //
    JPanel dashboardPanel = new JPanel();
    // HEADER //
    JPanel dashboardHeader = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toCompletedButton = new JButton("Completed");

    // CALENDAR IN DASHBOARD //
    JPanel calendarPanel = new JPanel();
    JPanel cardPanel = new JPanel();
    JPanel bottomPanel = new JPanel();
    Dashboard() {
        dashboardPanel.setLayout(new GridBagLayout());

        // HEADER //

        dashboardHeader.setLayout(new FlowLayout());
        dashboardHeader.setBackground(Color.CYAN);
        ((FlowLayout)dashboardHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        c.ipadx = 1000;
        dashboardPanel.add(dashboardHeader, c);

            // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setPreferredSize(new Dimension(200,70));
        toDashboardButton.setPreferredSize(new Dimension(200, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setPreferredSize(new Dimension(200,70));
        toTaskListButton.setPreferredSize(new Dimension(200, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setPreferredSize(new Dimension(200,70));
        toCalendarButton.setPreferredSize(new Dimension(200, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel completedButton = new JPanel();
        completedButton.setPreferredSize(new Dimension(200,70));
        toCompletedButton.setPreferredSize(new Dimension(200, 50));
        toCompletedButton.setBackground(Color.white);
        completedButton.add(toCompletedButton);
        dashboardHeader.add(dashboardButton);
        dashboardHeader.add(taskListButton);
        dashboardHeader.add(calendarButton);
        dashboardHeader.add(completedButton);

        // DASHBOARD CALENDAR //

        calendarPanel.setBackground(Color.green);
        calendarPanel.setLayout(new GridBagLayout());
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 150;
        dashboardPanel.add(calendarPanel, c);
        GridBagConstraints cell = new GridBagConstraints();
        for (int i = 0 ; i < 7; i++) {
            JPanel dayCell = new JPanel();
            dayCell.setPreferredSize(new Dimension(150, 100));
            dayCell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            cell.gridx = i;
            cell.gridy = 0;
            calendarPanel.add(dayCell, cell);
        }

            // add a 7 days calendar to the panel //

        JPanel weekCalendar = new JPanel();
        // DASHBOARD CARD //

        cardPanel.setBackground(Color.red);
        cardPanel.setLayout(new FlowLayout());
        ((FlowLayout)cardPanel.getLayout()).setHgap(100);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 2;
        c.ipady = 270;
        dashboardPanel.add(cardPanel, c);
        for (int i = 0; i < 4; i++) {
            JPanel card = new JPanel();
            card.setPreferredSize(new Dimension(200, 250));
            cardPanel.add(card);
        }
            // add CARD to DASHBOARD

        // DUE TODAY AND OVERDUE //

        bottomPanel.setBackground(Color.yellow);
        bottomPanel.setLayout(new GridBagLayout());
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 3;
        c.ipady = 280;
        dashboardPanel.add(bottomPanel, c);
        // ADD DUE TODAY //
        JPanel dueToday = new JPanel();
        dueToday.setPreferredSize(new Dimension(650,250));
        dueToday.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bottomPanel.add(dueToday);
        // ADD OVERDUE //
        JPanel overdue = new JPanel();
        overdue.setPreferredSize(new Dimension(650,250));
        overdue.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bottomPanel.add(overdue);

        dashboardFrame.add(dashboardPanel);
        dashboardFrame.setResizable(false);
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        dashboardFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
