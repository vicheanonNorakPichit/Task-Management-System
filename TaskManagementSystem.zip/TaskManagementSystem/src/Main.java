import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Main {
    static JFrame frame = new JFrame();
    // STATIC DECLARATION OF DASHBOARD //
    static Dashboard dashboard = new Dashboard();
    static Calendar calendar = new Calendar();
    static TaskList taskList = new TaskList();
    static Completed completed = new Completed();


    // CARD PANEL DECLARATION //
    public static void main(String[] args) {

        // FRAME //
        dashboard.dashboardFrame.setVisible(true);
        calendar.calendarFrame.setVisible(false);
        taskList.taskListFrame.setVisible(false);
        completed.completedFrame.setVisible(false);
        // add ACTION to HEADER BUTTON //
        dashboard.toCalendarButton.addActionListener(e -> {
            switchToCalendar();
        });
        dashboard.toTaskListButton.addActionListener(e -> {
            switchToTaskList();
        });
        dashboard.toCompletedButton.addActionListener(e -> {
            switchToCompleted();
        });
        calendar.toDashboardButton.addActionListener(e -> {
            switchToDashboard();
        });
        calendar.toTaskListButton.addActionListener(e -> {
            switchToTaskList();
        });
        calendar.toCompletedButton.addActionListener(e -> {
            switchToCompleted();
        });
        taskList.toDashboardButton.addActionListener(e -> {
            switchToDashboard();
        });
        taskList.toCalendarButton.addActionListener(e -> {
            switchToCalendar();
        });
        taskList.toCompletedButton.addActionListener(e -> {
            switchToCompleted();
        });
        completed.toDashboardButton.addActionListener(e -> {
            switchToDashboard();
        });
        completed.toCalendarButton.addActionListener(e -> {
            switchToCalendar();
        });
        completed.toTaskListButton.addActionListener(e -> {
            switchToTaskList();
        });
    }
    // Method for switching frame //
    static void switchToDashboard() {
        calendar.calendarFrame.setVisible(false);
        completed.completedFrame.setVisible(false);
        taskList.taskListFrame.setVisible(false);
        dashboard.dashboardFrame.setVisible(true);
    }
    static void switchToTaskList() {
        calendar.calendarFrame.setVisible(false);
        completed.completedFrame.setVisible(false);
        taskList.taskListFrame.setVisible(true);
        dashboard.dashboardFrame.setVisible(false);
    }
    static void switchToCalendar() {
        calendar.calendarFrame.setVisible(true);
        completed.completedFrame.setVisible(false);
        taskList.taskListFrame.setVisible(false);
        dashboard.dashboardFrame.setVisible(false);
    }
    static void switchToCompleted() {
        calendar.calendarFrame.setVisible(false);
        completed.completedFrame.setVisible(true);
        taskList.taskListFrame.setVisible(false);
        dashboard.dashboardFrame.setVisible(false);
    }

}