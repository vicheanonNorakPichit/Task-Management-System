import java.util.*;
public class Task {
    // Task Attributes //
    private String name;
    private String description;
    private String state;
    private String priority;
    private Date deadline;
    private int taskID;
    // getter //
    public String getName() {
        return name;
    }

    public Date getDeadline() {
        return deadline;
    }

    public String getDescription() {
        return description;
    }

    public String getPriority() {
        return priority;
    }

    public String getState() {
        return state;
    }
    public int getID() {
        return taskID;
    }
    // setter //

    Task(String name, String description, String state, String priority, Date deadline, int taskID) {
        this.name = name;
        this.deadline = deadline;
        this.description = description;
        this.priority = priority;
        this.state = state;
        this.taskID = taskID;
    }
    // Task Function //
    void edit() {

    }
    void delete() {

    }
    static void addTask() {

    }
}
