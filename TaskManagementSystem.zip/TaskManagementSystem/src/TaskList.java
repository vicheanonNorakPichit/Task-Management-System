import javax.swing.*;
import java.awt.*;

public class TaskList { // CLASS FOR TASK LIST FRAME
    JFrame taskListFrame = new JFrame();
    JPanel taskListPanel = new JPanel();
    JPanel taskListHeader = new JPanel();
    JPanel taskListMain = new JPanel();
    JPanel toDoPanel = new JPanel();
    JPanel doingPanel = new JPanel();
    JPanel noDeadlinePanel = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toCompletedButton = new JButton("Completed");
    TaskList() {
        taskListPanel.setLayout(new GridBagLayout());

        // HEADER //

        taskListHeader.setLayout(new FlowLayout());
        ((FlowLayout) taskListHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        c.ipadx = 1000;
        taskListPanel.add(taskListHeader, c);

        // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setPreferredSize(new Dimension(200, 70));
        toDashboardButton.setPreferredSize(new Dimension(200, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setPreferredSize(new Dimension(200, 70));
        toTaskListButton.setPreferredSize(new Dimension(200, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setPreferredSize(new Dimension(200, 70));
        toCalendarButton.setPreferredSize(new Dimension(200, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel completedButton = new JPanel();
        completedButton.setPreferredSize(new Dimension(200, 70));
        toCompletedButton.setPreferredSize(new Dimension(200, 50));
        toCompletedButton.setBackground(Color.white);
        completedButton.add(toCompletedButton);
        taskListHeader.add(dashboardButton);
        taskListHeader.add(taskListButton);
        taskListHeader.add(calendarButton);
        taskListHeader.add(completedButton);

        // Main Panel //
        taskListMain.setLayout(new GridLayout());
        taskListMain.setBackground(Color.gray);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 700;
        c.ipadx = 1000;
        taskListPanel.add(taskListMain, c);

        taskListFrame.add(taskListPanel);
        taskListFrame.setResizable(false);
        taskListFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        taskListFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
